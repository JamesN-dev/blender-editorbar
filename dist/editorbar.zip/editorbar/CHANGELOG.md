# Changelog

## [0.3.2] - 2025-10-10

- feat: Fix height slider flip bug and improve slider precision
- v0.3.1 - Sidebar Width Control Improvements
- feat: real-time preference monitoring with enhanced UI v0.3.0
- fix: resolve addon preferences not displaying in Blender UI
- refactor: fix preferences registration and improve preference access
- feat: add build script with dist output - Create build.py to package extension as zip - Add debug logging to EditorTogglePreferences.draw() - Update manifest and dependencies
- init: basic implementation of the outliner/property sidebar toggle

